package genesis;

public class ControllerMethod {
    private String[] controllerMethodAnnotations;
    private String controllerMethodParameter;
    private String controllerMethodContent;
    public String[] getControllerMethodAnnotations() {
        return controllerMethodAnnotations;
    }
    public void setControllerMethodAnnotations(String[] controllerMethodAnnotations) {
        this.controllerMethodAnnotations = controllerMethodAnnotations;
    }
    public String getControllerMethodParameter() {
        return controllerMethodParameter;
    }
    public void setControllerMethodParameter(String controllerMethodParameter) {
        this.controllerMethodParameter = controllerMethodParameter;
    }
    public String getControllerMethodContent() {
        return controllerMethodContent;
    }
    public void setControllerMethodContent(String controllerMethodContent) {
        this.controllerMethodContent = controllerMethodContent;
    }
    
}
