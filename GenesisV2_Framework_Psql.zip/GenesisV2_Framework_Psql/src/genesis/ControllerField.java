package genesis;

public class ControllerField {
    private String[] controllerFieldAnnotations;
    private String controllerFieldContent;
    public String[] getControllerFieldAnnotations() {
        return controllerFieldAnnotations;
    }
    public void setControllerFieldAnnotations(String[] controllerFieldAnnotations) {
        this.controllerFieldAnnotations = controllerFieldAnnotations;
    }
    public String getControllerFieldContent() {
        return controllerFieldContent;
    }
    public void setControllerFieldContent(String controllerFieldContent) {
        this.controllerFieldContent = controllerFieldContent;
    }
    
}
