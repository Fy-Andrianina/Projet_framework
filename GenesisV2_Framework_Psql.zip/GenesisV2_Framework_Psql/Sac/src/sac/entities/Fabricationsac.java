package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("fabricationsac")

public class Fabricationsac {
    @PrimaryKey
@Column("idfabrication")
private Integer idfabrication;
public Integer getIdfabrication(){ return idfabrication; }
public void setIdfabrication(Integer o){ idfabrication=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idsac")
private Sac sac;
public Sac getSac(){ return sac; }
public void setSac(Sac o){ sac=o; }
@Column("quantite")
private Integer quantite;
public Integer getQuantite(){ return quantite; }
public void setQuantite(Integer o){ quantite=o; }
@Column("date")
private java.time.LocalDate date;
public java.time.LocalDate getDate(){ return date; }
public void setDate(java.time.LocalDate o){ date=o; }

    public Fabricationsac(){}
public Fabricationsac(Integer o){ idfabrication=o; }

}

