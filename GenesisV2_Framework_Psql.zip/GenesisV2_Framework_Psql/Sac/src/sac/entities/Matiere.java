package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("matiere")

public class Matiere {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nommatiere")
private String nommatiere;
public String getNommatiere(){ return nommatiere; }
public void setNommatiere(String o){ nommatiere=o; }

    public Matiere(){}
public Matiere(Integer o){ id=o; }

}

