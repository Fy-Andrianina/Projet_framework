package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("profil")

public class Profil {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("coeff")
private Integer coeff;
public Integer getCoeff(){ return coeff; }
public void setCoeff(Integer o){ coeff=o; }
@Column("min")
private Integer min;
public Integer getMin(){ return min; }
public void setMin(Integer o){ min=o; }
@Column("max")
private Integer max;
public Integer getMax(){ return max; }
public void setMax(Integer o){ max=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("profil")
private Profilmodel profilmodel;
public Profilmodel getProfilmodel(){ return profilmodel; }
public void setProfilmodel(Profilmodel o){ profilmodel=o; }

    public Profil(){}
public Profil(Integer o){ id=o; }

}

