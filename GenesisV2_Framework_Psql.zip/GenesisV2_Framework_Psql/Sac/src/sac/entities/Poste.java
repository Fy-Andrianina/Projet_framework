package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("poste")

public class Poste {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nom_poste")
private String nomPoste;
public String getNomPoste(){ return nomPoste; }
public void setNomPoste(String o){ nomPoste=o; }

    public Poste(){}
public Poste(Integer o){ id=o; }

}

