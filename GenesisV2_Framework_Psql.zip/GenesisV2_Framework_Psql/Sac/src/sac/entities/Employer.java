package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("employer")

public class Employer {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idposte")
private Poste poste;
public Poste getPoste(){ return poste; }
public void setPoste(Poste o){ poste=o; }
@Column("date_embauche")
private java.time.LocalDate dateEmbauche;
public java.time.LocalDate getDateEmbauche(){ return dateEmbauche; }
public void setDateEmbauche(java.time.LocalDate o){ dateEmbauche=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idpersonne")
private Personne personne;
public Personne getPersonne(){ return personne; }
public void setPersonne(Personne o){ personne=o; }
@Column("matricule")
private String matricule;
public String getMatricule(){ return matricule; }
public void setMatricule(String o){ matricule=o; }

    public Employer(){}
public Employer(Integer o){ id=o; }

}

