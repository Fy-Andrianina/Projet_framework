package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("taille_travailleur")

public class TailleTravailleur {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idtaille")
private Taille taille;
public Taille getTaille(){ return taille; }
public void setTaille(Taille o){ taille=o; }
@Column("nb_travailleurs")
private Integer nbTravailleurs;
public Integer getNbTravailleurs(){ return nbTravailleurs; }
public void setNbTravailleurs(Integer o){ nbTravailleurs=o; }

    public TailleTravailleur(){}
public TailleTravailleur(Integer o){ id=o; }

}

