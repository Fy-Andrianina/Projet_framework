package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("sac")

public class Sac {
    @PrimaryKey
@Column("idsac")
private Integer idsac;
public Integer getIdsac(){ return idsac; }
public void setIdsac(Integer o){ idsac=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("taille")
private Taille taille;
public Taille getTaille(){ return taille; }
public void setTaille(Taille o){ taille=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("type")
private Type type;
public Type getType(){ return type; }
public void setType(Type o){ type=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("look")
private Look look;
public Look getLook(){ return look; }
public void setLook(Look o){ look=o; }

    public Sac(){}
public Sac(Integer o){ idsac=o; }

}

