package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("tjm")

public class Tjm {
    @PrimaryKey
@Column("idtjm")
private Integer idtjm;
public Integer getIdtjm(){ return idtjm; }
public void setIdtjm(Integer o){ idtjm=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idposte")
private Poste poste;
public Poste getPoste(){ return poste; }
public void setPoste(Poste o){ poste=o; }
@Column("valeur")
private Integer valeur;
public Integer getValeur(){ return valeur; }
public void setValeur(Integer o){ valeur=o; }
@Column("date")
private java.time.LocalDate date;
public java.time.LocalDate getDate(){ return date; }
public void setDate(java.time.LocalDate o){ date=o; }

    public Tjm(){}
public Tjm(Integer o){ idtjm=o; }

}

