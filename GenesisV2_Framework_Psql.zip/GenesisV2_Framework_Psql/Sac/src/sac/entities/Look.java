package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("look")

public class Look {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nomlook")
private String nomlook;
public String getNomlook(){ return nomlook; }
public void setNomlook(String o){ nomlook=o; }

    public Look(){}
public Look(Integer o){ id=o; }

}

