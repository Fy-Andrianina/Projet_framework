package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("achat_sac")

public class AchatSac {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idclient")
private Client client;
public Client getClient(){ return client; }
public void setClient(Client o){ client=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idsac")
private Sac sac;
public Sac getSac(){ return sac; }
public void setSac(Sac o){ sac=o; }
@Column("quantite")
private Double quantite;
public Double getQuantite(){ return quantite; }
public void setQuantite(Double o){ quantite=o; }
@Column("date")
private java.time.LocalDate date;
public java.time.LocalDate getDate(){ return date; }
public void setDate(java.time.LocalDate o){ date=o; }

    public AchatSac(){}
public AchatSac(Integer o){ id=o; }

}

