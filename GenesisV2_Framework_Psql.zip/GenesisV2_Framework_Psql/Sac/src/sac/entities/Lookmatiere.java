package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("lookmatiere")

public class Lookmatiere {
    @PrimaryKey
@Column("idlookmatiere")
private Integer idlookmatiere;
public Integer getIdlookmatiere(){ return idlookmatiere; }
public void setIdlookmatiere(Integer o){ idlookmatiere=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idlook")
private Look look;
public Look getLook(){ return look; }
public void setLook(Look o){ look=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idmatiere")
private Matiere matiere;
public Matiere getMatiere(){ return matiere; }
public void setMatiere(Matiere o){ matiere=o; }

    public Lookmatiere(){}
public Lookmatiere(Integer o){ idlookmatiere=o; }

}

