package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("personne")

public class Personne {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nom")
private String nom;
public String getNom(){ return nom; }
public void setNom(String o){ nom=o; }
@Column("prenom")
private String prenom;
public String getPrenom(){ return prenom; }
public void setPrenom(String o){ prenom=o; }
@Column("date_naissance")
private java.time.LocalDate dateNaissance;
public java.time.LocalDate getDateNaissance(){ return dateNaissance; }
public void setDateNaissance(java.time.LocalDate o){ dateNaissance=o; }
@Column("sexe")
private Integer sexe;
public Integer getSexe(){ return sexe; }
public void setSexe(Integer o){ sexe=o; }

    public Personne(){}
public Personne(Integer o){ id=o; }

}

