package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("compositionsac")

public class Compositionsac {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idsac")
private Sac sac;
public Sac getSac(){ return sac; }
public void setSac(Sac o){ sac=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idmatiere")
private Matiere matiere;
public Matiere getMatiere(){ return matiere; }
public void setMatiere(Matiere o){ matiere=o; }
@Column("quantite")
private Integer quantite;
public Integer getQuantite(){ return quantite; }
public void setQuantite(Integer o){ quantite=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idunite")
private Unite unite;
public Unite getUnite(){ return unite; }
public void setUnite(Unite o){ unite=o; }

    public Compositionsac(){}
public Compositionsac(Integer o){ id=o; }

}

