package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("look_heure")

public class LookHeure {
    @Column("heure")
private Integer heure;
public Integer getHeure(){ return heure; }
public void setHeure(Integer o){ heure=o; }
@PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("date")
private java.time.LocalDate date;
public java.time.LocalDate getDate(){ return date; }
public void setDate(java.time.LocalDate o){ date=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idlook")
private Look look;
public Look getLook(){ return look; }
public void setLook(Look o){ look=o; }

    public LookHeure(){}
public LookHeure(Integer o){ id=o; }

}

