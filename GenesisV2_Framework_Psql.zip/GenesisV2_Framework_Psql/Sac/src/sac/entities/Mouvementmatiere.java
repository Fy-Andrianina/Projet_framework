package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("mouvementmatiere")

public class Mouvementmatiere {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idmatiere")
private Matiere matiere;
public Matiere getMatiere(){ return matiere; }
public void setMatiere(Matiere o){ matiere=o; }
@Column("quantite")
private Double quantite;
public Double getQuantite(){ return quantite; }
public void setQuantite(Double o){ quantite=o; }
@Column("idmvt")
private Integer idmvt;
public Integer getIdmvt(){ return idmvt; }
public void setIdmvt(Integer o){ idmvt=o; }
@Column("prix")
private Integer prix;
public Integer getPrix(){ return prix; }
public void setPrix(Integer o){ prix=o; }
@Column("date")
private java.time.LocalDate date;
public java.time.LocalDate getDate(){ return date; }
public void setDate(java.time.LocalDate o){ date=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idfournisseur")
private Fournisseur fournisseur;
public Fournisseur getFournisseur(){ return fournisseur; }
public void setFournisseur(Fournisseur o){ fournisseur=o; }

    public Mouvementmatiere(){}
public Mouvementmatiere(Integer o){ id=o; }

}

