package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("profilmodel")

public class Profilmodel {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nom_profil")
private String nomProfil;
public String getNomProfil(){ return nomProfil; }
public void setNomProfil(String o){ nomProfil=o; }

    public Profilmodel(){}
public Profilmodel(Integer o){ id=o; }

}

