package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("service")

public class Service {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nom_service")
private String nomService;
public String getNomService(){ return nomService; }
public void setNomService(String o){ nomService=o; }

    public Service(){}
public Service(Integer o){ id=o; }

}

