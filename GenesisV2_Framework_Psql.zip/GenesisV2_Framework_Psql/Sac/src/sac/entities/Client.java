package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("client")

public class Client {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idpersonne")
private Personne personne;
public Personne getPersonne(){ return personne; }
public void setPersonne(Personne o){ personne=o; }

    public Client(){}
public Client(Integer o){ id=o; }

}

