package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("taille")

public class Taille {
    @PrimaryKey
@Column("idtaille")
private Integer idtaille;
public Integer getIdtaille(){ return idtaille; }
public void setIdtaille(Integer o){ idtaille=o; }
@Column("nomtaille")
private String nomtaille;
public String getNomtaille(){ return nomtaille; }
public void setNomtaille(String o){ nomtaille=o; }
@Column("coeff")
private Integer coeff;
public Integer getCoeff(){ return coeff; }
public void setCoeff(Integer o){ coeff=o; }

    public Taille(){}
public Taille(Integer o){ idtaille=o; }

}

