package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("travailleur_sac")

public class TravailleurSac {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idsac")
private Sac sac;
public Sac getSac(){ return sac; }
public void setSac(Sac o){ sac=o; }
@veda.godao.annotations.ForeignKey(recursive=true)
@Column("idposte")
private Poste poste;
public Poste getPoste(){ return poste; }
public void setPoste(Poste o){ poste=o; }

    public TravailleurSac(){}
public TravailleurSac(Integer o){ id=o; }

}

