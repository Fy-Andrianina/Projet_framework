package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("type")

public class Type {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nomtype")
private String nomtype;
public String getNomtype(){ return nomtype; }
public void setNomtype(String o){ nomtype=o; }

    public Type(){}
public Type(Integer o){ id=o; }

}

