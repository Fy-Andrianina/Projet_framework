package sac.entities;
import veda.godao.annotations.Column;
import veda.godao.annotations.Table;
import veda.godao.annotations.PrimaryKey;

@Table("fournisseur")

public class Fournisseur {
    @PrimaryKey
@Column("id")
private Integer id;
public Integer getId(){ return id; }
public void setId(Integer o){ id=o; }
@Column("nomfournisseur")
private String nomfournisseur;
public String getNomfournisseur(){ return nomfournisseur; }
public void setNomfournisseur(String o){ nomfournisseur=o; }

    public Fournisseur(){}
public Fournisseur(Integer o){ id=o; }

}

