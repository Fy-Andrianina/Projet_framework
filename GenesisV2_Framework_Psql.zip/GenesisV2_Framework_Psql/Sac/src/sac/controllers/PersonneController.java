package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Personne;

@Controller
@Singleton

public class PersonneController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertpersonne.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Personne o=new Personne();
    o.setNom(entity.getData().get("nom"));o.setPrenom(entity.getData().get("prenom"));o.setDateNaissance(java.time.LocalDate.parse(entity.getData().get("dateNaissance")));o.setSexe(Integer.parseInt(entity.getData().get("sexe")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudpersonne.do");
        return model;
    }
}
@URLMapping("tocrudpersonne.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Personne[] o=dao.select(connex, Personne.class);
        model.addItem("viewpage", "personne.jsp");
        model.addItem("title", "Personne");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updatepersonne.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Personne o=new Personne();
    o.setNom(entity.getData().get("nom"));o.setPrenom(entity.getData().get("prenom"));o.setDateNaissance(java.time.LocalDate.parse(entity.getData().get("dateNaissance")));o.setSexe(Integer.parseInt(entity.getData().get("sexe")));
    Personne where=new Personne();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudpersonne.do");
        return model;
    }
}
@URLMapping("deletepersonne.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Personne where=new Personne();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudpersonne.do");
        return model;
    }
}

}

