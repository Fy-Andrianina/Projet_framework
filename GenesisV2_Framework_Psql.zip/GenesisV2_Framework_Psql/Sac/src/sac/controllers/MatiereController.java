package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Matiere;

@Controller
@Singleton

public class MatiereController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertmatiere.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Matiere o=new Matiere();
    o.setNommatiere(entity.getData().get("nommatiere"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmatiere.do");
        return model;
    }
}
@URLMapping("tocrudmatiere.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Matiere[] o=dao.select(connex, Matiere.class);
        model.addItem("viewpage", "matiere.jsp");
        model.addItem("title", "Matiere");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updatematiere.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Matiere o=new Matiere();
    o.setNommatiere(entity.getData().get("nommatiere"));
    Matiere where=new Matiere();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmatiere.do");
        return model;
    }
}
@URLMapping("deletematiere.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Matiere where=new Matiere();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmatiere.do");
        return model;
    }
}

}

