package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Profil;

@Controller
@Singleton

public class ProfilController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertprofil.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Profil o=new Profil();
    o.setCoeff(Integer.parseInt(entity.getData().get("coeff")));o.setMin(Integer.parseInt(entity.getData().get("min")));o.setMax(Integer.parseInt(entity.getData().get("max")));o.setProfilmodel(new sac.entities.Profilmodel(Integer.parseInt(entity.getData().get("profilmodel"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofil.do");
        return model;
    }
}
@URLMapping("tocrudprofil.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Profil[] o=dao.select(connex, Profil.class);
        model.addItem("viewpage", "profil.jsp");
        model.addItem("title", "Profil");
        model.addItem("o", o);
        sac.entities.Profilmodel[] profilmodel=dao.select(connex, sac.entities.Profilmodel.class);
model.addItem("profilmodels", profilmodel);
        return model;
    }
}
@URLMapping("updateprofil.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Profil o=new Profil();
    o.setCoeff(Integer.parseInt(entity.getData().get("coeff")));o.setMin(Integer.parseInt(entity.getData().get("min")));o.setMax(Integer.parseInt(entity.getData().get("max")));o.setProfilmodel(new sac.entities.Profilmodel(Integer.parseInt(entity.getData().get("profilmodel"))));
    Profil where=new Profil();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofil.do");
        return model;
    }
}
@URLMapping("deleteprofil.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Profil where=new Profil();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofil.do");
        return model;
    }
}

}

