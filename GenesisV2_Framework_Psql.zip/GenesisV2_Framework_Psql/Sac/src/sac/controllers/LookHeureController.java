package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.LookHeure;

@Controller
@Singleton

public class LookHeureController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertlookHeure.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    LookHeure o=new LookHeure();
    o.setHeure(Integer.parseInt(entity.getData().get("heure")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookHeure.do");
        return model;
    }
}
@URLMapping("tocrudlookHeure.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        LookHeure[] o=dao.select(connex, LookHeure.class);
        model.addItem("viewpage", "lookHeure.jsp");
        model.addItem("title", "LookHeure");
        model.addItem("o", o);
        sac.entities.Look[] look=dao.select(connex, sac.entities.Look.class);
model.addItem("looks", look);
        return model;
    }
}
@URLMapping("updatelookHeure.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    LookHeure o=new LookHeure();
    o.setHeure(Integer.parseInt(entity.getData().get("heure")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));
    LookHeure where=new LookHeure();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookHeure.do");
        return model;
    }
}
@URLMapping("deletelookHeure.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    LookHeure where=new LookHeure();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookHeure.do");
        return model;
    }
}

}

