package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Tjm;

@Controller
@Singleton

public class TjmController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("inserttjm.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Tjm o=new Tjm();
    o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));o.setValeur(Integer.parseInt(entity.getData().get("valeur")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtjm.do");
        return model;
    }
}
@URLMapping("tocrudtjm.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Tjm[] o=dao.select(connex, Tjm.class);
        model.addItem("viewpage", "tjm.jsp");
        model.addItem("title", "Tjm");
        model.addItem("o", o);
        sac.entities.Poste[] poste=dao.select(connex, sac.entities.Poste.class);
model.addItem("postes", poste);
        return model;
    }
}
@URLMapping("updatetjm.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Tjm o=new Tjm();
    o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));o.setValeur(Integer.parseInt(entity.getData().get("valeur")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    Tjm where=new Tjm();
    where.setIdtjm(Integer.parseInt(entity.getData().get("idtjm")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtjm.do");
        return model;
    }
}
@URLMapping("deletetjm.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Tjm where=new Tjm();
    where.setIdtjm(Integer.parseInt(entity.getData().get("idtjm")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtjm.do");
        return model;
    }
}

}

