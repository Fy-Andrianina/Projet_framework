package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Profilmodel;

@Controller
@Singleton

public class ProfilmodelController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertprofilmodel.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Profilmodel o=new Profilmodel();
    o.setNomProfil(entity.getData().get("nomProfil"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofilmodel.do");
        return model;
    }
}
@URLMapping("tocrudprofilmodel.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Profilmodel[] o=dao.select(connex, Profilmodel.class);
        model.addItem("viewpage", "profilmodel.jsp");
        model.addItem("title", "Profilmodel");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updateprofilmodel.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Profilmodel o=new Profilmodel();
    o.setNomProfil(entity.getData().get("nomProfil"));
    Profilmodel where=new Profilmodel();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofilmodel.do");
        return model;
    }
}
@URLMapping("deleteprofilmodel.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Profilmodel where=new Profilmodel();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprofilmodel.do");
        return model;
    }
}

}

