package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Client;

@Controller
@Singleton

public class ClientController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertclient.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Client o=new Client();
    o.setPersonne(new sac.entities.Personne(Integer.parseInt(entity.getData().get("personne"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudclient.do");
        return model;
    }
}
@URLMapping("tocrudclient.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Client[] o=dao.select(connex, Client.class);
        model.addItem("viewpage", "client.jsp");
        model.addItem("title", "Client");
        model.addItem("o", o);
        sac.entities.Personne[] personne=dao.select(connex, sac.entities.Personne.class);
model.addItem("personnes", personne);
        return model;
    }
}
@URLMapping("updateclient.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Client o=new Client();
    o.setPersonne(new sac.entities.Personne(Integer.parseInt(entity.getData().get("personne"))));
    Client where=new Client();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudclient.do");
        return model;
    }
}
@URLMapping("deleteclient.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Client where=new Client();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudclient.do");
        return model;
    }
}

}

