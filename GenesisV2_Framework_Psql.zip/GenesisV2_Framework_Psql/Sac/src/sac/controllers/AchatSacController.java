package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.AchatSac;

@Controller
@Singleton

public class AchatSacController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertachatSac.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    AchatSac o=new AchatSac();
    o.setClient(new sac.entities.Client(Integer.parseInt(entity.getData().get("client"))));o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setQuantite(Double.parseDouble(entity.getData().get("quantite")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudachatSac.do");
        return model;
    }
}
@URLMapping("tocrudachatSac.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        AchatSac[] o=dao.select(connex, AchatSac.class);
        model.addItem("viewpage", "achatSac.jsp");
        model.addItem("title", "AchatSac");
        model.addItem("o", o);
        sac.entities.Client[] client=dao.select(connex, sac.entities.Client.class);
model.addItem("clients", client);sac.entities.Sac[] sac=dao.select(connex, sac.entities.Sac.class);
model.addItem("sacs", sac);
        return model;
    }
}
@URLMapping("updateachatSac.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    AchatSac o=new AchatSac();
    o.setClient(new sac.entities.Client(Integer.parseInt(entity.getData().get("client"))));o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setQuantite(Double.parseDouble(entity.getData().get("quantite")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    AchatSac where=new AchatSac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudachatSac.do");
        return model;
    }
}
@URLMapping("deleteachatSac.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    AchatSac where=new AchatSac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudachatSac.do");
        return model;
    }
}

}

