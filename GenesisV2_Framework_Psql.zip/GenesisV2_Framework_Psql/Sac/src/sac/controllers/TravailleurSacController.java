package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.TravailleurSac;

@Controller
@Singleton

public class TravailleurSacController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("inserttravailleurSac.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    TravailleurSac o=new TravailleurSac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtravailleurSac.do");
        return model;
    }
}
@URLMapping("tocrudtravailleurSac.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        TravailleurSac[] o=dao.select(connex, TravailleurSac.class);
        model.addItem("viewpage", "travailleurSac.jsp");
        model.addItem("title", "TravailleurSac");
        model.addItem("o", o);
        sac.entities.Sac[] sac=dao.select(connex, sac.entities.Sac.class);
model.addItem("sacs", sac);sac.entities.Poste[] poste=dao.select(connex, sac.entities.Poste.class);
model.addItem("postes", poste);
        return model;
    }
}
@URLMapping("updatetravailleurSac.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    TravailleurSac o=new TravailleurSac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));
    TravailleurSac where=new TravailleurSac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtravailleurSac.do");
        return model;
    }
}
@URLMapping("deletetravailleurSac.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    TravailleurSac where=new TravailleurSac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtravailleurSac.do");
        return model;
    }
}

}

