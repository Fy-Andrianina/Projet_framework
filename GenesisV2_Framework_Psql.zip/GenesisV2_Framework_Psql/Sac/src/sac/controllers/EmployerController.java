package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Employer;

@Controller
@Singleton

public class EmployerController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertemployer.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Employer o=new Employer();
    o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));o.setDateEmbauche(java.time.LocalDate.parse(entity.getData().get("dateEmbauche")));o.setPersonne(new sac.entities.Personne(Integer.parseInt(entity.getData().get("personne"))));o.setMatricule(entity.getData().get("matricule"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudemployer.do");
        return model;
    }
}
@URLMapping("tocrudemployer.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Employer[] o=dao.select(connex, Employer.class);
        model.addItem("viewpage", "employer.jsp");
        model.addItem("title", "Employer");
        model.addItem("o", o);
        sac.entities.Poste[] poste=dao.select(connex, sac.entities.Poste.class);
model.addItem("postes", poste);sac.entities.Personne[] personne=dao.select(connex, sac.entities.Personne.class);
model.addItem("personnes", personne);
        return model;
    }
}
@URLMapping("updateemployer.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Employer o=new Employer();
    o.setPoste(new sac.entities.Poste(Integer.parseInt(entity.getData().get("poste"))));o.setDateEmbauche(java.time.LocalDate.parse(entity.getData().get("dateEmbauche")));o.setPersonne(new sac.entities.Personne(Integer.parseInt(entity.getData().get("personne"))));o.setMatricule(entity.getData().get("matricule"));
    Employer where=new Employer();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudemployer.do");
        return model;
    }
}
@URLMapping("deleteemployer.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Employer where=new Employer();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudemployer.do");
        return model;
    }
}

}

