package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Prixvente;

@Controller
@Singleton

public class PrixventeController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertprixvente.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Prixvente o=new Prixvente();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setValeur(Double.parseDouble(entity.getData().get("valeur")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprixvente.do");
        return model;
    }
}
@URLMapping("tocrudprixvente.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Prixvente[] o=dao.select(connex, Prixvente.class);
        model.addItem("viewpage", "prixvente.jsp");
        model.addItem("title", "Prixvente");
        model.addItem("o", o);
        sac.entities.Sac[] sac=dao.select(connex, sac.entities.Sac.class);
model.addItem("sacs", sac);
        return model;
    }
}
@URLMapping("updateprixvente.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Prixvente o=new Prixvente();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setValeur(Double.parseDouble(entity.getData().get("valeur")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    Prixvente where=new Prixvente();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprixvente.do");
        return model;
    }
}
@URLMapping("deleteprixvente.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Prixvente where=new Prixvente();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudprixvente.do");
        return model;
    }
}

}

