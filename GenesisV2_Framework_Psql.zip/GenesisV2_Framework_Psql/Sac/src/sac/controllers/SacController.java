package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Sac;

@Controller
@Singleton

public class SacController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertsac.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Sac o=new Sac();
    o.setTaille(new sac.entities.Taille(Integer.parseInt(entity.getData().get("taille"))));o.setType(new sac.entities.Type(Integer.parseInt(entity.getData().get("type"))));o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudsac.do");
        return model;
    }
}
@URLMapping("tocrudsac.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Sac[] o=dao.select(connex, Sac.class);
        model.addItem("viewpage", "sac.jsp");
        model.addItem("title", "Sac");
        model.addItem("o", o);
        sac.entities.Taille[] taille=dao.select(connex, sac.entities.Taille.class);
model.addItem("tailles", taille);sac.entities.Type[] type=dao.select(connex, sac.entities.Type.class);
model.addItem("types", type);sac.entities.Look[] look=dao.select(connex, sac.entities.Look.class);
model.addItem("looks", look);
        return model;
    }
}
@URLMapping("updatesac.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Sac o=new Sac();
    o.setTaille(new sac.entities.Taille(Integer.parseInt(entity.getData().get("taille"))));o.setType(new sac.entities.Type(Integer.parseInt(entity.getData().get("type"))));o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));
    Sac where=new Sac();
    where.setIdsac(Integer.parseInt(entity.getData().get("idsac")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudsac.do");
        return model;
    }
}
@URLMapping("deletesac.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Sac where=new Sac();
    where.setIdsac(Integer.parseInt(entity.getData().get("idsac")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudsac.do");
        return model;
    }
}

}

