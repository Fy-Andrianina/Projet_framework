package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Fournisseur;

@Controller
@Singleton

public class FournisseurController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertfournisseur.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Fournisseur o=new Fournisseur();
    o.setNomfournisseur(entity.getData().get("nomfournisseur"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfournisseur.do");
        return model;
    }
}
@URLMapping("tocrudfournisseur.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Fournisseur[] o=dao.select(connex, Fournisseur.class);
        model.addItem("viewpage", "fournisseur.jsp");
        model.addItem("title", "Fournisseur");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updatefournisseur.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Fournisseur o=new Fournisseur();
    o.setNomfournisseur(entity.getData().get("nomfournisseur"));
    Fournisseur where=new Fournisseur();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfournisseur.do");
        return model;
    }
}
@URLMapping("deletefournisseur.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Fournisseur where=new Fournisseur();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfournisseur.do");
        return model;
    }
}

}

