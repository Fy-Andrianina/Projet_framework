package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Unite;

@Controller
@Singleton

public class UniteController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertunite.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Unite o=new Unite();
    o.setNom(entity.getData().get("nom"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudunite.do");
        return model;
    }
}
@URLMapping("tocrudunite.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Unite[] o=dao.select(connex, Unite.class);
        model.addItem("viewpage", "unite.jsp");
        model.addItem("title", "Unite");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updateunite.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Unite o=new Unite();
    o.setNom(entity.getData().get("nom"));
    Unite where=new Unite();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudunite.do");
        return model;
    }
}
@URLMapping("deleteunite.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Unite where=new Unite();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudunite.do");
        return model;
    }
}

}

