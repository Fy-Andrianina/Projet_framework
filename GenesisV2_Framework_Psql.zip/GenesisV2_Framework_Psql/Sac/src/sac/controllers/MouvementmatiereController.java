package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Mouvementmatiere;

@Controller
@Singleton

public class MouvementmatiereController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertmouvementmatiere.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Mouvementmatiere o=new Mouvementmatiere();
    o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));o.setQuantite(Double.parseDouble(entity.getData().get("quantite")));o.setIdmvt(Integer.parseInt(entity.getData().get("idmvt")));o.setPrix(Integer.parseInt(entity.getData().get("prix")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));o.setFournisseur(new sac.entities.Fournisseur(Integer.parseInt(entity.getData().get("fournisseur"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmouvementmatiere.do");
        return model;
    }
}
@URLMapping("tocrudmouvementmatiere.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Mouvementmatiere[] o=dao.select(connex, Mouvementmatiere.class);
        model.addItem("viewpage", "mouvementmatiere.jsp");
        model.addItem("title", "Mouvementmatiere");
        model.addItem("o", o);
        sac.entities.Matiere[] matiere=dao.select(connex, sac.entities.Matiere.class);
model.addItem("matieres", matiere);sac.entities.Fournisseur[] fournisseur=dao.select(connex, sac.entities.Fournisseur.class);
model.addItem("fournisseurs", fournisseur);
        return model;
    }
}
@URLMapping("updatemouvementmatiere.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Mouvementmatiere o=new Mouvementmatiere();
    o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));o.setQuantite(Double.parseDouble(entity.getData().get("quantite")));o.setIdmvt(Integer.parseInt(entity.getData().get("idmvt")));o.setPrix(Integer.parseInt(entity.getData().get("prix")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));o.setFournisseur(new sac.entities.Fournisseur(Integer.parseInt(entity.getData().get("fournisseur"))));
    Mouvementmatiere where=new Mouvementmatiere();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmouvementmatiere.do");
        return model;
    }
}
@URLMapping("deletemouvementmatiere.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Mouvementmatiere where=new Mouvementmatiere();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudmouvementmatiere.do");
        return model;
    }
}

}

