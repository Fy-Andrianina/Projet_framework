package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Fabricationsac;

@Controller
@Singleton

public class FabricationsacController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertfabricationsac.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Fabricationsac o=new Fabricationsac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setQuantite(Integer.parseInt(entity.getData().get("quantite")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfabricationsac.do");
        return model;
    }
}
@URLMapping("tocrudfabricationsac.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Fabricationsac[] o=dao.select(connex, Fabricationsac.class);
        model.addItem("viewpage", "fabricationsac.jsp");
        model.addItem("title", "Fabricationsac");
        model.addItem("o", o);
        sac.entities.Sac[] sac=dao.select(connex, sac.entities.Sac.class);
model.addItem("sacs", sac);
        return model;
    }
}
@URLMapping("updatefabricationsac.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Fabricationsac o=new Fabricationsac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setQuantite(Integer.parseInt(entity.getData().get("quantite")));o.setDate(java.time.LocalDate.parse(entity.getData().get("date")));
    Fabricationsac where=new Fabricationsac();
    where.setIdfabrication(Integer.parseInt(entity.getData().get("idfabrication")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfabricationsac.do");
        return model;
    }
}
@URLMapping("deletefabricationsac.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Fabricationsac where=new Fabricationsac();
    where.setIdfabrication(Integer.parseInt(entity.getData().get("idfabrication")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudfabricationsac.do");
        return model;
    }
}

}

