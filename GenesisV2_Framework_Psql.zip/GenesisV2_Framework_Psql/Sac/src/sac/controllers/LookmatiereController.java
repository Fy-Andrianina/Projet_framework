package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Lookmatiere;

@Controller
@Singleton

public class LookmatiereController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertlookmatiere.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Lookmatiere o=new Lookmatiere();
    o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookmatiere.do");
        return model;
    }
}
@URLMapping("tocrudlookmatiere.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Lookmatiere[] o=dao.select(connex, Lookmatiere.class);
        model.addItem("viewpage", "lookmatiere.jsp");
        model.addItem("title", "Lookmatiere");
        model.addItem("o", o);
        sac.entities.Look[] look=dao.select(connex, sac.entities.Look.class);
model.addItem("looks", look);sac.entities.Matiere[] matiere=dao.select(connex, sac.entities.Matiere.class);
model.addItem("matieres", matiere);
        return model;
    }
}
@URLMapping("updatelookmatiere.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Lookmatiere o=new Lookmatiere();
    o.setLook(new sac.entities.Look(Integer.parseInt(entity.getData().get("look"))));o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));
    Lookmatiere where=new Lookmatiere();
    where.setIdlookmatiere(Integer.parseInt(entity.getData().get("idlookmatiere")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookmatiere.do");
        return model;
    }
}
@URLMapping("deletelookmatiere.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Lookmatiere where=new Lookmatiere();
    where.setIdlookmatiere(Integer.parseInt(entity.getData().get("idlookmatiere")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudlookmatiere.do");
        return model;
    }
}

}

