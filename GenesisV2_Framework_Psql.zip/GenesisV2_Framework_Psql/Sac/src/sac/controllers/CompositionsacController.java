package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Compositionsac;

@Controller
@Singleton

public class CompositionsacController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertcompositionsac.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Compositionsac o=new Compositionsac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));o.setQuantite(Integer.parseInt(entity.getData().get("quantite")));o.setUnite(new sac.entities.Unite(Integer.parseInt(entity.getData().get("unite"))));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudcompositionsac.do");
        return model;
    }
}
@URLMapping("tocrudcompositionsac.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Compositionsac[] o=dao.select(connex, Compositionsac.class);
        model.addItem("viewpage", "compositionsac.jsp");
        model.addItem("title", "Compositionsac");
        model.addItem("o", o);
        sac.entities.Sac[] sac=dao.select(connex, sac.entities.Sac.class);
model.addItem("sacs", sac);sac.entities.Matiere[] matiere=dao.select(connex, sac.entities.Matiere.class);
model.addItem("matieres", matiere);sac.entities.Unite[] unite=dao.select(connex, sac.entities.Unite.class);
model.addItem("unites", unite);
        return model;
    }
}
@URLMapping("updatecompositionsac.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Compositionsac o=new Compositionsac();
    o.setSac(new sac.entities.Sac(Integer.parseInt(entity.getData().get("sac"))));o.setMatiere(new sac.entities.Matiere(Integer.parseInt(entity.getData().get("matiere"))));o.setQuantite(Integer.parseInt(entity.getData().get("quantite")));o.setUnite(new sac.entities.Unite(Integer.parseInt(entity.getData().get("unite"))));
    Compositionsac where=new Compositionsac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudcompositionsac.do");
        return model;
    }
}
@URLMapping("deletecompositionsac.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Compositionsac where=new Compositionsac();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudcompositionsac.do");
        return model;
    }
}

}

