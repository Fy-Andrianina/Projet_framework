package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Service;

@Controller
@Singleton

public class ServiceController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("insertservice.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Service o=new Service();
    o.setNomService(entity.getData().get("nomService"));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudservice.do");
        return model;
    }
}
@URLMapping("tocrudservice.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Service[] o=dao.select(connex, Service.class);
        model.addItem("viewpage", "service.jsp");
        model.addItem("title", "Service");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updateservice.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Service o=new Service();
    o.setNomService(entity.getData().get("nomService"));
    Service where=new Service();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudservice.do");
        return model;
    }
}
@URLMapping("deleteservice.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Service where=new Service();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudservice.do");
        return model;
    }
}

}

