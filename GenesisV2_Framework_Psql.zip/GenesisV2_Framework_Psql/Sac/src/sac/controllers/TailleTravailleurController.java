package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.TailleTravailleur;

@Controller
@Singleton

public class TailleTravailleurController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("inserttailleTravailleur.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    TailleTravailleur o=new TailleTravailleur();
    o.setTaille(new sac.entities.Taille(Integer.parseInt(entity.getData().get("taille"))));o.setNbTravailleurs(Integer.parseInt(entity.getData().get("nbTravailleurs")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtailleTravailleur.do");
        return model;
    }
}
@URLMapping("tocrudtailleTravailleur.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        TailleTravailleur[] o=dao.select(connex, TailleTravailleur.class);
        model.addItem("viewpage", "tailleTravailleur.jsp");
        model.addItem("title", "TailleTravailleur");
        model.addItem("o", o);
        sac.entities.Taille[] taille=dao.select(connex, sac.entities.Taille.class);
model.addItem("tailles", taille);
        return model;
    }
}
@URLMapping("updatetailleTravailleur.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    TailleTravailleur o=new TailleTravailleur();
    o.setTaille(new sac.entities.Taille(Integer.parseInt(entity.getData().get("taille"))));o.setNbTravailleurs(Integer.parseInt(entity.getData().get("nbTravailleurs")));
    TailleTravailleur where=new TailleTravailleur();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtailleTravailleur.do");
        return model;
    }
}
@URLMapping("deletetailleTravailleur.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    TailleTravailleur where=new TailleTravailleur();
    where.setId(Integer.parseInt(entity.getData().get("id")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtailleTravailleur.do");
        return model;
    }
}

}

