package sac.controllers;
import eriq.flamework.annotations.Controller;
import eriq.flamework.annotations.Singleton;
import eriq.flamework.annotations.URLMapping;
import eriq.flamework.model.ModelRedirect;
import eriq.flamework.model.ModelView;
import eriq.flamework.servlet.ServletEntity;
import veda.godao.DAO;
import veda.godao.utils.DAOConnexion;
import java.sql.Connection;
import sac.entities.Taille;

@Controller
@Singleton

public class TailleController {
    private DAO dao=new DAO("poketra", "localhost", "5432", "postgres", "postgres", false, 2);

    
    @URLMapping("inserttaille.do")
public ModelRedirect insert(ServletEntity entity) throws Exception{
    Taille o=new Taille();
    o.setNomtaille(entity.getData().get("nomtaille"));o.setCoeff(Integer.parseInt(entity.getData().get("coeff")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.insertWithoutPrimaryKey(connex, o);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtaille.do");
        return model;
    }
}
@URLMapping("tocrudtaille.do")
public ModelView crudpage(ServletEntity entity) throws Exception{
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        ModelView model=new ModelView();
        model.setView("pages/layout/layout.jsp");
        Taille[] o=dao.select(connex, Taille.class);
        model.addItem("viewpage", "taille.jsp");
        model.addItem("title", "Taille");
        model.addItem("o", o);
        
        return model;
    }
}
@URLMapping("updatetaille.do")
public ModelRedirect update(ServletEntity entity) throws Exception{
    Taille o=new Taille();
    o.setNomtaille(entity.getData().get("nomtaille"));o.setCoeff(Integer.parseInt(entity.getData().get("coeff")));
    Taille where=new Taille();
    where.setIdtaille(Integer.parseInt(entity.getData().get("idtaille")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.update(connex, o, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtaille.do");
        return model;
    }
}
@URLMapping("deletetaille.do")
public ModelRedirect delete(ServletEntity entity) throws Exception{
    Taille where=new Taille();
    where.setIdtaille(Integer.parseInt(entity.getData().get("idtaille")));
    try(Connection connex=DAOConnexion.getConnexion("org.postgresql.Driver", "postgresql", "localhost", "5432", "poketra", "postgres", "postgres", false, true)){
        dao.delete(connex, where);
        connex.commit();
        ModelRedirect model=new ModelRedirect("tocrudtaille.do");
        return model;
    }
}

}

