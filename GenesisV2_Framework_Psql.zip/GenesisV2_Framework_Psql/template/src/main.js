import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.css';
import { createApp } from 'vue';
import { createRouter, createWebHistory } from 'vue-router';
import App from './App.vue';
import AuteurCreate from './components/pages/AuteurCreate';
import AuteurEdit from './components/pages/AuteurEdit';
import AuteurList from './components/pages/AuteurList';
import AuteurShow from './components/pages/AuteurShow';
import EditeurCreate from './components/pages/EditeurCreate';
import EditeurEdit from './components/pages/EditeurEdit';
import EditeurList from './components/pages/EditeurList';
import EditeurShow from './components/pages/EditeurShow';
import LivreCreate from './components/pages/LivreCreate';
import LivreEdit from './components/pages/LivreEdit';
import LivreList from './components/pages/LivreList';
import LivreShow from './components/pages/LivreShow';
import WelcomeFile from './components/pages/WelcomeFile';
		
  
axios.defaults.baseURL = process.env.VUE_APP_API_URL
axios.interceptors.request.use(function (config) {
  config.headers['X-Binarybox-Api-Key'] = process.env.VUE_APP_API_KEY;
  return config;
});
  
const router = createRouter({
  history: createWebHistory(),
  routes: [
	{path:'/', component:WelcomeFile},
    { path: '/AuteurEdit/:id', component: AuteurEdit  },
		{ path: '/AuteurShow/:id', component: AuteurShow  },
		{ path: '/EditeurEdit/:id', component: EditeurEdit  },
		{ path: '/EditeurShow/:id', component: EditeurShow  },
		{ path: '/LivreEdit/:id', component: LivreEdit  },
		{ path: '/LivreShow/:id', component: LivreShow  },
		{ path: '/AuteurCreate', component: AuteurCreate  },
		{ path: '/AuteurList', component: AuteurList  },
		{ path: '/EditeurCreate', component: EditeurCreate  },
		{ path: '/EditeurList', component: EditeurList  },
		{ path: '/LivreCreate', component: LivreCreate  },
		{ path: '/LivreList', component: LivreList  }, 
		
		
  ],
});
  
createApp(App).use(router).mount('#app');