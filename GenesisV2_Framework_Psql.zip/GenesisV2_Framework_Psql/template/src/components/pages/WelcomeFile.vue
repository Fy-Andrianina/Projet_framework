<template>
<div class="container">
<h2>Bienvenue sur Our_Bootik</h2>
</div>
</template>
<script>
export default {
  name: 'WelcomeFile',
}
</script>
<style>
</style>
