<template>
<div class="container">
  <div class="card">
<h2>Bienvenue sur Our_Bootik</h2>
<h6>Apprecier nos services</h6>
</div>
</div>
</template>
<script>
export default {
  name: 'WelcomeFile',
}
</script>
   <style>
.card{
  margin-left: 250px;
  margin: 20% 20% 20% 20%;
  text-align: center;
 }
 </style>
